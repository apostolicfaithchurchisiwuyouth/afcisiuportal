(function(){
"use strict";

const $=id=>document.getElementById(id);
const show=e=>{if(e)e.hidden=false};
const hide=e=>{if(e)e.hidden=true};
const icons=()=>{if(window.lucide&&typeof window.lucide.createIcons==="function")window.lucide.createIcons()};

function storedUser(){
  const keys=["afc_isiu_auth_user","afc_isiu_user","auth_user","currentUser","user"];
  for(const key of keys){
    try{
      const raw=localStorage.getItem(key); if(!raw)continue;
      const v=JSON.parse(raw), u=v&&typeof v==="object"?(v.user||v.data||v):null;
      if(u&&typeof u==="object")return u;
    }catch(_){}
  }
  return null;
}

function user(){
  const objects=[window.AUTH,window.Auth,window.authState];
  for(const a of objects){
    if(!a)continue;
    for(const m of ["getUser","getCurrentUser"]){
      try{if(typeof a[m]==="function"){const u=a[m]();if(u)return u}}catch(_){}
    }
    if(a.currentUser&&typeof a.currentUser==="object")return a.currentUser;
  }
  return storedUser();
}

function loggedIn(){
  const objects=[window.AUTH,window.Auth,window.authState];
  for(const a of objects){
    if(!a)continue;
    for(const m of ["isLoggedIn","isAuthenticated","isAuth","hasSession"]){
      try{if(typeof a[m]==="function")return !!a[m]()}catch(_){}
    }
  }
  return !!user();
}

function firstName(u){
  if(!u)return"Friend";
  for(const v of [u.firstName,u.firstname,u.first_name,u.givenName,u.given_name]){
    if(typeof v==="string"&&v.trim())return v.trim().split(/\s+/)[0];
  }
  const full=u.name||u.fullName||u.full_name||u.displayName||u.display_name;
  return typeof full==="string"&&full.trim()?full.trim().split(/\s+/)[0]:"Friend";
}

function avatarUrl(u){
  if(!u)return null;
  for(const v of [u.avatar,u.avatarUrl,u.avatarURL,u.photo,u.photoUrl,u.photoURL,u.profileImage,u.profileImageUrl,u.image,u.imageUrl]){
    if(typeof v==="string"&&v.trim())return v.trim();
  }
  return null;
}

function avatar(el,u){
  if(!el)return;
  const name=firstName(u),letter=(name[0]||"A").toUpperCase(),url=avatarUrl(u);
  el.innerHTML="";
  if(!url){el.textContent=letter;return}
  const img=document.createElement("img");img.src=url;img.alt=name+"'s profile picture";
  img.onerror=()=>{el.innerHTML="";el.textContent=letter};
  el.appendChild(img);
}

function menuIcon(open){
  const b=$("mobileMenuButton");if(!b)return;
  b.setAttribute("aria-expanded",String(open));
  b.setAttribute("aria-label",open?"Close navigation menu":"Open navigation menu");
  const i=b.querySelector("[data-lucide]");if(i)i.setAttribute("data-lucide",open?"x":"menu");
  icons();
}
function openMenu(){$("sidebar")?.classList.add("open");$("mobileOverlay")?.classList.add("active");document.body.classList.add("mobile-menu-open");menuIcon(true)}
function closeMenu(){$("sidebar")?.classList.remove("open");$("mobileOverlay")?.classList.remove("active");document.body.classList.remove("mobile-menu-open");menuIcon(false)}
function toggleMenu(){ $("sidebar")?.classList.contains("open")?closeMenu():openMenu() }

function updateHome(){
  const member=loggedIn(),u=user(),name=firstName(u);
  document.querySelectorAll(".member-only").forEach(e=>e.hidden=!member);

  if(member&&u){
    hide($("guestHero"));show($("memberHero"));hide($("guestInformation"));show($("memberDashboardContent"));
    if($("welcomeUserName"))$("welcomeUserName").textContent=name;
    if($("sidebarUserName"))$("sidebarUserName").textContent=name;
    hide($("sidebarGuest"));show($("sidebarMember"));avatar($("sidebarAvatar"),u);
    const h=$("headerAccountButton");if(h){h.href="pages/profile.html";h.setAttribute("aria-label","My profile");avatar($("headerAvatarContent"),u)}
    hide($("guestBottomProfile"));show($("memberBottomProfile"));avatar($("bottomAvatar"),u);
  }else{
    show($("guestHero"));hide($("memberHero"));show($("guestInformation"));hide($("memberDashboardContent"));
    show($("sidebarGuest"));hide($("sidebarMember"));
    const h=$("headerAccountButton");if(h){h.href="login.html";h.setAttribute("aria-label","Login");$("headerAvatarContent").innerHTML='<span data-lucide="user-round"></span>'}
    show($("guestBottomProfile"));hide($("memberBottomProfile"));
  }
  icons();
}

async function logout(){
  try{
    const a=window.AUTH||window.Auth;
    if(a&&typeof a.logout==="function")await a.logout();
    else["afc_isiu_auth_user","afc_isiu_auth_session","afc_isiu_user","auth_user","currentUser","user"].forEach(k=>localStorage.removeItem(k));
  }catch(e){console.error("AFC Portal logout failed:",e)}
  closeMenu();updateHome();
}

function init(){
  $("mobileMenuButton")?.addEventListener("click",e=>{e.preventDefault();toggleMenu()});
  $("mobileOverlay")?.addEventListener("click",closeMenu);
  $("sidebar")?.addEventListener("click",e=>{if(e.target.closest("a")&&innerWidth<=900)closeMenu()});
  $("sidebarLogoutButton")?.addEventListener("click",logout);
  $("heroLogoutButton")?.addEventListener("click",logout);
  document.addEventListener("keydown",e=>{if(e.key==="Escape")closeMenu()});
  addEventListener("resize",()=>{if(innerWidth>900)closeMenu()});
  ["authchange","auth-state-changed","authStateChanged","login","logout","user-login","user-logout"].forEach(n=>addEventListener(n,()=>setTimeout(updateHome,30)));
  addEventListener("storage",e=>{if(["afc_isiu_auth_user","afc_isiu_auth_session","afc_isiu_user","currentUser"].includes(e.key))updateHome()});
  icons();updateHome();setTimeout(updateHome,150);setTimeout(updateHome,500);setTimeout(updateHome,1200);
}

document.readyState==="loading"?document.addEventListener("DOMContentLoaded",init,{once:true}):init();
window.openMobileMenu=openMenu;window.closeMobileMenu=closeMenu;window.toggleMobileMenu=toggleMenu;window.updatePersonalizedHome=updateHome;
})();